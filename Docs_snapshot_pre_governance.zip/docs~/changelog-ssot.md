# changelog-ssot — ALWTTT

This changelog records **semantic/documentary changes**.
Cosmetic edits should not be logged here.

---

## 2026-03-18 — Governance migration Batch 01 initialized

### Added
- root governed docs spine:
  - `README.md`
  - `SSoT_INDEX.md`
  - `SSoT_CONTRACTS.md`
  - `CURRENT_STATE.md`
  - `coverage-matrix.md`
  - `changelog-ssot.md`

### Established documentary rules
- one major concept must have one primary home
- planning/reference/archive cannot silently override SSoTs
- `CURRENT_STATE.md` is a live state layer, not a replacement for subsystem SSoTs

### Established cross-project boundary rule
- ALWTTT owns gameplay/runtime/integration truth
- MidiGenPlay owns package internals
- shared concepts must be split into boundary contracts rather than duplicated authority

### Key classification decision
- `MidiMusicManager` is to be documented as **ALWTTT runtime/integration truth**, not as MidiGenPlay package truth

### Migration impact
- future subsystem batches now have a stable governed target
- current previous docs remain source material until subsystem SSoTs are promoted
