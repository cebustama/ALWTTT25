# coverage-matrix — ALWTTT

This matrix maps each major concept to its intended authoritative home.

During migration, some rows still point to source docs rather than final governed docs.
That is temporary and should be eliminated batch by batch.

| Concept / subsystem | Primary authority now | Intended final authority | Status | Notes |
|---|---|---|---|---|
| Root documentation rules | `SSoT_CONTRACTS.md` | `SSoT_CONTRACTS.md` | active | documentary governance is now rooted here |
| Current implementation slice | `CURRENT_STATE.md` | `CURRENT_STATE.md` | active | live status layer only |
| Card gameplay semantics | previous `reference/Card.md` | `systems/SSoT_Card_System.md` | pending promotion | includes action vs composition split |
| Card authoring/import contracts | previous `canon/Appendix_Authoring_DataContracts.md` | `systems/SSoT_Card_Authoring_Contracts.md` | pending promotion | real contract source, not just appendix |
| Gig/combat core rules | previous `reference/Gig_Combat.md` + combat canon delta | `systems/SSoT_Gig_Combat_Core.md` | pending promotion | current authority is split and must be unified |
| Gig encounter structure | previous `reference/Gig.md` | `systems/SSoT_Gig_Encounter.md` | planned | encounter-level truth |
| Audience member / reactions | previous `reference/AudienceMember.md` | `systems/SSoT_Audience_and_Reactions.md` | planned | should separate entity model from tactical examples |
| Status system | previous `reference/StatusEffects.md` | `systems/SSoT_Status_Effects.md` | planned | gameplay/runtime status truth |
| CSO primitive catalog | previous `reference/StatusEffects_Primitives_with_References.md` | `reference/CSO_Primitives_Catalog.md` | reference | supporting catalog, not primary runtime authority |
| LoopScore / SongHype / Vibe | previous backlog/reference mixed material | `systems/SSoT_Scoring_and_Meters.md` | planned | currently under-documented as governed truth |
| Runtime phase flow | previous combat/gig docs | `runtime/SSoT_Runtime_Flow.md` | planned | deck/hand → play card → execute → resolve loop/song |
| Composition session runtime bridge | previous composition subsystem docs | `runtime/SSoT_Runtime_CompositionSession_Integration.md` | planned | ALWTTT-owned runtime truth |
| ALWTTT ↔ MidiGenPlay authority split | none explicit | `integrations/midigenplay/SSoT_ALWTTT_MidiGenPlay_Boundary.md` | planned | must be explicit before subsystem migration continues |
| `MidiMusicManager` integration behavior | none explicit | `integrations/midigenplay/SSoT_ALWTTT_MidiMusicManager_Integration.md` | planned | ALWTTT runtime truth, not package truth |
| MidiGenPlay package internals | MidiGenPlay docs | MidiGenPlay docs | external authority | ALWTTT must reference, not duplicate |
| Roadmaps / future work | previous roadmap/backlog docs | `planning/` | planning only | non-authoritative |
| Legacy docs / superseded models | previous `archive/` | `archive/` | archive | keep for context, never as primary truth |
