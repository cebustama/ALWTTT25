# CURRENT_STATE — ALWTTT

This file tracks the currently validated slice and immediate documentary obligations.

---

## 1. Active project slice now

### Gameplay / combat slice currently validated in docs
- deck/hand pipeline is operating in play mode
- cards can be played end-to-end
- effect execution is working in the current MVP slice
- validated effect examples include vibe, stress, and status application

### Composition / music slice currently present in project structure
The project currently contains ALWTTT-side runtime components for:
- `GigManager`
- `MidiMusicManager`
- `CompositionSession`
- `SongConfigBuilder`
- composition UI/prefabs

This means ALWTTT already owns a real runtime music/session surface and needs explicit governed integration docs rather than hand-wavy references.

---

## 2. What was just completed

### Documentation governance — Batch 01
Completed in this batch:
- root governed documentation spine created
- authority rules formalized
- initial coverage matrix created
- explicit ALWTTT vs MidiGenPlay ownership rule established
- current-state tracking initialized

This is a governance batch, not yet a subsystem rewrite batch.

---

## 3. What is next

### Recommended next migration batch
**Batch 02 — Combat/Card authority batch**

Priority order:
1. create `systems/SSoT_Gig_Combat_Core.md`
2. create `systems/SSoT_Card_System.md`
3. promote authoring/data contracts into `systems/SSoT_Card_Authoring_Contracts.md`
4. reclassify the previous combat roadmap as planning only

---

## 4. Current blockers / unresolved documentary risks

### Blocker A — mixed authority in previous docs
The previous docs set mixes:
- canon snapshots,
- reference docs that act like authority,
- roadmap docs,
- and mixed ALWTTT/MidiGenPlay composition material.

### Blocker B — composition/midi boundary still not split into governed docs
The previous composition pipeline material still mixes:
- ALWTTT gameplay semantics,
- ALWTTT runtime integration,
- MidiGenPlay package internals,
- and authoring tooling.

### Blocker C — legacy card model risk
The project tree still shows `CardData.cs` alongside the newer effect/payload-based card model.
This must be documented explicitly as either:
- active legacy coexistence,
- transitional compatibility,
- or superseded material.

---

## 5. Docs that need editing next

Immediate next docs to create/update:
- `systems/SSoT_Gig_Combat_Core.md`
- `systems/SSoT_Card_System.md`
- `systems/SSoT_Card_Authoring_Contracts.md`
- `coverage-matrix.md` after those docs exist
- `changelog-ssot.md` with subsystem promotion entries

Next after that:
- `runtime/SSoT_Runtime_Flow.md`
- `runtime/SSoT_Runtime_CompositionSession_Integration.md`
- `integrations/midigenplay/SSoT_ALWTTT_MidiGenPlay_Boundary.md`

---

## 6. Last validated source basis for this snapshot

This snapshot is grounded in:
- the previous ALWTTT docs set
- the project tree showing ALWTTT runtime/game/music components
- the first-pass boundary diagnosis performed during governance migration
