# ALWTTT Documentation

This folder is the governed documentation root for **A Long Way to the Top (ALWTTT)**.

It is being built through a **safe, parallel migration** from the previous documentation set.
This means the older docs are not treated as deleted truth; they are being reclassified into:

- **SSoT / governed truth**
- **current state tracking**
- **planning**
- **reference**
- **archive**
- **cross-project integration material**

---

## What this docs set must answer

This documentation system exists to make it easy to answer:

- what is true **today** in ALWTTT,
- what belongs to **ALWTTT gameplay/runtime truth**,
- what belongs to **MidiGenPlay package truth**,
- what is only **integration boundary truth**,
- what is **planned but not implemented**,
- and what changed recently.

---

## Authority order

When documents disagree, use this order:

1. `SSoT_CONTRACTS.md`
2. Relevant subsystem SSoT listed in `SSoT_INDEX.md`
3. `CURRENT_STATE.md` for latest validated active slice / immediate next step
4. `coverage-matrix.md` for authority lookup
5. `planning/` for future work only
6. `reference/` for explanatory/supporting material
7. `archive/` for legacy/historical context only

---

## Cross-project rule: ALWTTT vs MidiGenPlay

### ALWTTT owns
- game runtime truth
- card gameplay semantics
- gig/combat/session truth
- audience and scoring truth
- scene/runtime integration behavior
- `MidiMusicManager` as a game runtime/integration component

### MidiGenPlay owns
- package internals for procedural MIDI generation
- composer internals
- package-side authoring internals
- algorithmic details that are not game-owned behavior

### Shared boundary rule
If a concept crosses both systems:
- ALWTTT may document the **observable contract and runtime handoff**.
- ALWTTT must **not silently redefine** MidiGenPlay package internals.
- MidiGenPlay may mention ALWTTT usage, but ALWTTT remains authority for game behavior.

---

## Root governance files

- `SSoT_INDEX.md` — master map of authoritative docs and intended final homes
- `SSoT_CONTRACTS.md` — documentary rules and authority boundaries
- `CURRENT_STATE.md` — active validated implementation slice, recent completion, next step, blockers
- `coverage-matrix.md` — subsystem-to-authority mapping
- `changelog-ssot.md` — semantic documentary changes only

---

## Migration status

This is **Batch 01** of the governance migration.

Batch 01 intentionally does **not** rewrite all gameplay docs yet.
It establishes the governance spine first so later migrations have a stable target.

Current batch creates:
- the root governance docs,
- the initial ALWTTT vs MidiGenPlay boundary rule,
- the first authority map,
- and the first migration-safe current-state snapshot.

---

## What comes next

Recommended next governed migration batches:

1. **Batch 02 — Combat/Card authority batch**
   - create `systems/SSoT_Gig_Combat_Core.md`
   - create `systems/SSoT_Card_System.md`
   - promote authoring/data contracts into governed form

2. **Batch 03 — Runtime + music integration batch**
   - create `runtime/SSoT_Runtime_Flow.md`
   - create `runtime/SSoT_Runtime_CompositionSession_Integration.md`
   - create `integrations/midigenplay/SSoT_ALWTTT_MidiGenPlay_Boundary.md`

3. **Batch 04 — Audience/status/scoring batch**
   - audience reactions
   - status effects
   - loop score / song hype / vibe

---

## Working rule during migration

Do not overwrite the previous docs set until:

- the governed replacements exist,
- authority collisions have been resolved,
- cross-references are repaired,
- and the coverage matrix shows one primary home per major concept.
