# SSoT_INDEX — ALWTTT

This file is the master index for governed documentation.

It defines:
- which docs are authoritative,
- which docs are transitional,
- which docs are only planning/reference/archive,
- and which major concepts still require promotion into proper SSoTs.

---

## Root governance docs

| Document | Role | Status |
|---|---|---|
| `README.md` | root entry + authority order | active |
| `SSoT_CONTRACTS.md` | documentary governance rules | active |
| `CURRENT_STATE.md` | validated current slice + next step | active |
| `coverage-matrix.md` | authority lookup | active |
| `changelog-ssot.md` | semantic/documentary change history | active |
| `SSoT_INDEX.md` | authority map / index | active |

---

## Intended subsystem SSoTs

### Systems

| Intended document | Primary scope | Status |
|---|---|---|
| `systems/SSoT_Gig_Combat_Core.md` | gig/combat rules, meters, loop/song hooks, turn structure | planned |
| `systems/SSoT_Card_System.md` | card model, action vs composition semantics, payload boundaries | planned |
| `systems/SSoT_Card_Authoring_Contracts.md` | authoring/import/editor contracts for cards and statuses | planned (promotion target) |
| `systems/SSoT_Audience_and_Reactions.md` | audience entities, tastes, impression rules, reaction contracts | planned |
| `systems/SSoT_Status_Effects.md` | runtime status truth and catalogue-facing gameplay semantics | planned |
| `systems/SSoT_Scoring_and_Meters.md` | loop score, song hype, vibe, flow/composure/stress scoring relationships | planned |
| `systems/SSoT_Gig_Encounter.md` | encounter-level structure / gig setup truth | planned |

### Runtime

| Intended document | Primary scope | Status |
|---|---|---|
| `runtime/SSoT_Runtime_Flow.md` | runtime managers, phase flow, deck/hand → play → execute → resolve | planned |
| `runtime/SSoT_Runtime_CompositionSession_Integration.md` | ALWTTT-side composition/session runtime bridge | planned |

### Integrations

| Intended document | Primary scope | Status |
|---|---|---|
| `integrations/midigenplay/SSoT_ALWTTT_MidiGenPlay_Boundary.md` | explicit ownership split and contract boundary | planned |
| `integrations/midigenplay/SSoT_ALWTTT_MidiMusicManager_Integration.md` | `MidiMusicManager` as ALWTTT runtime integration truth | planned |

---

## Transitional source docs from the previous set

These are important source inputs, but they are **not the final governed structure**.

| Previous doc | Current role in migration | Intended fate |
|---|---|---|
| `canon/SSoT_Combat.md` | delta snapshot only | absorb into `CURRENT_STATE.md` + combat SSoT, then archive snapshot |
| `canon/Roadmap_Combat.md` | planning only | move to `planning/` |
| `canon/Appendix_Authoring_DataContracts.md` | real contract source | promote into `systems/SSoT_Card_Authoring_Contracts.md` |
| `reference/Gig_Combat.md` | major source of combat truth | absorb into `systems/SSoT_Gig_Combat_Core.md` |
| `reference/Card.md` | major source of card truth | absorb into `systems/SSoT_Card_System.md` |
| `reference/AudienceMember.md` | source for audience truth | absorb into `systems/SSoT_Audience_and_Reactions.md` |
| `reference/StatusEffects.md` | source for status truth | absorb into `systems/SSoT_Status_Effects.md` |
| `reference/subsystems/Composition Pipeline/*` | mixed ALWTTT + MidiGenPlay material | split into runtime integration / boundary / package-owned reference |

---

## Explicit non-authority categories

These documents are useful, but are **not** primary truth:

- roadmap docs
- backlog docs
- research prompts
- historical progress reports
- archived snapshots
- legacy docs

Those must not silently define current implementation truth.
